﻿using System;
using System.Collections.Generic;
using System.Text;
using DbApp.Controllers;
using System.Web;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
//using Microsoft.EntityFrameworkCore;

namespace ConsoleServer
{
   
    
    class Method
    {

        public class Contact
        {
            public int contactId { get; set; }
            public string firstname { get; set; }
            public string surname { get; set; }
            public string phone1 { get; set; }
            public string phone2 { get; set; }
            public string info { get; set; }
            public int groupId { get; set; }
        }

        public class Group
        {
            public int groupId { get; set; }
            public int key { get; set; }
        }

        public class User
        {
            public int userId { get; set; }
            public string username { get; set; }
            public int salt { get; set; }
            public int passwordHash { get; set; }
            public int groupId { get; set; }

        }

        public class MainDbContext : DbContext
        {

            //подключаемся к базушке
           // protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
           // {
            //    optionsBuilder.UseSqlite("Filename=App_Data/sqlite.db");
            //    Database.EnsureCreated();
            //}

            public static DbSet<Contact> Contacts { get; set; }
            public static  DbSet<Group> Groups { get; set; }
            public static DbSet<User> Users { get; set; }

            public  bool AddNewContact(Contact c)
            {
                try
                {
                    Contacts.Add(c);
                    SaveChanges();
                    return true;
                }
                catch (Exception) { return false; }
            }
            public  bool UpdateContact(Contact c)
            {
                try {
                    //Contacts.Update
                    return true; }
                catch (Exception) { return false; }
            }
            public  bool DeleteContact(Contact c)
            {
                try {
                    Contacts.Remove(c);
                    SaveChanges();
                    return true; }
                catch (Exception) { return false; }

            }

            public bool CheckPassword(User u)
            {
                if (Users.Find(u) == null)
                {
                    return true;
                }
                else { return false; }
            }
        }


       
    }
}
