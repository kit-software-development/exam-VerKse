﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
//using ConnectionLibrary;

namespace ConsoleServer
{
    class Program
    {
        static Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        public readonly static string  sucMes = "Action was done";
        public readonly static string  eMes = "Action was falled";
        private static readonly Method.MainDbContext context = new Method.MainDbContext();

        static void Main(string[] args)
        {
            

            socket.Bind(new IPEndPoint(IPAddress.Any, 8080));//8080));
            //начинаем прослушивать сокет
            socket.Listen(10);// 10 Connections.usersNum);
            
            Socket client = socket.Accept();
            byte[] buffer = new byte[1024];
            try
            {
                client.Receive(buffer);
            }
            catch (System.Net.Sockets.SocketException)
            {
                Console.WriteLine(DateTime.Now + "  Client ended connection");
            }
            Console.WriteLine(DateTime.Now + "  New client connection");

            while (true)
            {
                client.Receive(buffer);
                string message = Encoding.ASCII.GetString(buffer);
                int code = Convert.ToInt32(message.Substring(message.Length - 1, 1));
                int dateLeng = Convert.ToInt32(message.Substring(2));
                string actionDate = message.Substring(2, dateLeng);
                Console.WriteLine(actionDate + ":  ");

                CodeDictionary codes = new CodeDictionary();
                if (code != 0) { Console.Write(codes.action[code]); }

                switch (code)
                {
                    case 0: //write message
                        int cleanMesLen = message.Length - 2 - dateLeng - 2 - 1;
                        message = message.Substring(2 + dateLeng + 2 - 1, cleanMesLen);
                        Console.Write(message);
                        //Console.WriteLine(Encoding.ASCII.GetString(buffer));
                        Console.WriteLine();
                        break;
                    case 1://add contact
                        try
                        {
                            Method.Contact c = new Method.Contact();
                            client.Receive(buffer);
                            context.AddNewContact(c);
                            Console.WriteLine(sucMes);
                        }
                        catch (Exception) {
                            Console.WriteLine(eMes);
                        }
                        break;
                    case 2://update contact
                        try
                        {
                            Method.Contact c = new Method.Contact();
                            context.UpdateContact(c);
                            Console.WriteLine(sucMes);
                        }
                        catch (Exception)
                        {
                            Console.WriteLine(eMes);
                        }
                        break;
                    case 3://delete contact
                        try
                        {
                            Method.Contact c = new Method.Contact();
                            context.DeleteContact(c);
                            Console.WriteLine(sucMes);
                        }
                        catch (Exception)
                        {
                            Console.WriteLine(eMes);
                        }
                        break;
                    case 4://log-check
                        try
                        {

                            client.Receive(buffer);
                            string userName = Encoding.ASCII.GetString(buffer);
                            string password = Encoding.ASCII.GetString(buffer);
                            Method.User u = new Method.User();
                            string mes = Convert.ToString(context.CheckPassword(u));
                            buffer = Encoding.ASCII.GetBytes(mes);
                            socket.Send(buffer);
                           
                            Console.WriteLine(sucMes);
                        }
                        catch (Exception)
                        {
                            Console.WriteLine(eMes);
                        }
                        break;
                    case 5://other
                        Console.WriteLine("Server hasn't got this action liryc");
                        break;
                }

                socket.Shutdown(SocketShutdown.Both);
                socket.Close();
               // Console.WriteLine(Encoding.ASCII.GetString(buffer));
                Console.ReadLine();
            }
        }
    }
}
