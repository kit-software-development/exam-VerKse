﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp
{
    public partial class Auth : Form
    {
        string actionDate; // переменная. содержащая длину даты + дату
        public Auth()
        {
            InitializeComponent();
        }

        private void Auth_Load(object sender, EventArgs e)
        {

        }

        private void Phone1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            // т.к. не удалось настроить соединение с базой, оставим срабатывание кнопкни вне зависимости от пароля
            this.Hide();
            Form1 form1 = new Form1();
            form1.Show();

            /*
             //try to connect
             string user = textBoxLoggin.Text;
             string password = textBoxPassword.Text;

             if ((user != null) && (password != null))
                     {
                 //передаём данные на сервер
                 actionDate = Convert.ToString(DateTime.Now);
                 actionDate = actionDate.Length + actionDate;
                 string message = actionDate + "4";
                 byte[] buffer = Encoding.ASCII.GetBytes(message);
                 Program.socket.Send(buffer);
                 Program.socket.Send(Encoding.ASCII.GetBytes(textBoxLoggin.Text));
                 Program.socket.Send(Encoding.ASCII.GetBytes(textBoxPassword.Text));

                 Program.socket.Receive(buffer, buffer.Length, 0);
                 StringBuilder builder = new StringBuilder();
                 int bytes = 0; // количество полученных байт

                 do
                 {
                     bytes = Program.socket.Receive(buffer, buffer.Length, 0);
                     builder.Append(Encoding.Unicode.GetString(buffer, 0, bytes));
                 }
                 while (Program.socket.Available > 0);

                 if (builder.ToString() == "true")
                 {
                     //если ок открываем соединение
                     actionDate = Convert.ToString(DateTime.Now);
                     actionDate = actionDate.Length + actionDate;
                     this.Hide();
                     Form1 form1 = new Form1();
                     form1.Show();
                     message = actionDate + "  User was authorized" + "0";
                     buffer = Encoding.ASCII.GetBytes(message);
                     Program.socket.Send(buffer);
                 }

                 else
                 {
                     //если не ок
                     actionDate = Convert.ToString(DateTime.Now);
                     actionDate = actionDate.Length + actionDate;
                     string message2 = actionDate + "  User write wrong password" + "0";
                     byte[] buffer2 = Encoding.ASCII.GetBytes(message2);
                     Program.socket.Send(buffer);
                     textBoxPassword.BackColor = Color.Salmon;                        }
                }
            */
        }

        private void TextBoxpassword_TextChanged(object sender, EventArgs e)
        {
          
        }

     
    }
}
