﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp;

namespace WindowsFormsApp
{
    public partial class Form1 : Form
    {
        string actionDate; // переменная. содержащая длину даты + дату
        public Form1()
        {
            InitializeComponent();
            //запрос к базу через код 5 о передаче списка для вошедшего пользователя 
            flowLayoutPanel1.Controls.AddRange(new contactsControl[]
                {
                new contactsControl(1,"SomeName","SomeSurname","+1 (234) 56","+2 (234) 56","First human in the world"),
                new contactsControl(2,"AnotherName","AnotherSurname","+3 (234) 56","+4 (234) 54","Second human in the world")});

        }

        private void PhoneBook_Load(object sender, EventArgs e)
        {

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void TabPage2_Click(object sender, EventArgs e)
        {

        }

        private void TabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TabPage1_Click(object sender, EventArgs e)
        {

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            // addButton
            string firstname = newNameTextBox.Text;
            string surname = newSurnameTextBox.Text;
            string phone1 = newPhone1textBox.Text;
            string phone2 = newPhone2textBox.Text;
            string info = newInfoTextBox.Text;

            //передача данных на сервер
            actionDate = Convert.ToString(DateTime.Now);
            actionDate = actionDate.Length + actionDate;
            string message = actionDate + "1";
            byte[] buffer = Encoding.ASCII.GetBytes(message);
            Program.socket.Send(buffer);
            Program.socket.Send(Encoding.ASCII.GetBytes(newNameTextBox.Text));
            Program.socket.Send(Encoding.ASCII.GetBytes(newSurnameTextBox.Text));
            Program.socket.Send(Encoding.ASCII.GetBytes(newPhone1textBox.Text));
            Program.socket.Send(Encoding.ASCII.GetBytes(newPhone2textBox.Text));
            Program.socket.Send(Encoding.ASCII.GetBytes(newInfoTextBox.Text));

        }

        private void TabPage3_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {

        }

        private void Button2_Click(object sender, EventArgs e)
        {

        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Info_Click(object sender, EventArgs e)
        {

        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void Phone1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void Phone2_Click(object sender, EventArgs e)
        {

        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button2_Click_1(object sender, EventArgs e)
        {
            //exit
            actionDate = Convert.ToString(DateTime.Now);
            actionDate = actionDate.Length + actionDate;
            string message = actionDate + "  User close connection" + "0";
            byte[] buffer = Encoding.ASCII.GetBytes(message);
            Program.socket.Send(buffer);
            Program.socket.Close();
            this.Hide();
            Auth auth = new Auth();
            auth.Show();
        }
    }
}
