﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ConnectionLibrary;

namespace WindowsFormsApp
{
    static class Program
    {
        public static Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        
        
       
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try { socket.Connect(Connections.loopback, Connections.port); }
            catch (System.Net.Sockets.SocketException) { }

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Auth());

            string message = Console.ReadLine();

            byte[] buffer = Encoding.ASCII.GetBytes(message);
            socket.Send(buffer);
         
        }
    }
}
