﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleServ
{
    public class Actions
    {
        public enum codes
        {
            WRITE_MESSAGE,
            ADD_CONTACT,
            UPDATE_CONTACT,
            DELETE_CONTACT,
            LOG_CHECH,
            OTHER
        }
    }
}
