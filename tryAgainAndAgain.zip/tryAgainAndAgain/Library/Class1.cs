﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Library
{
    public class Class1
    {
        public class Contact
        {
            public int contactId { get; set; }
            public string firstname { get; set; }
            public string surname { get; set; }
            public string phone1 { get; set; }
            public string phone2 { get; set; }
            public string info { get; set; }
            public int groupId { get; set; }
        }

        public class Group
        {
            public int groupId { get; set; }
            public int key { get; set; }
        }

        public class User
        {
            public int userId { get; set; }
            public string username { get; set; }
            public string password { get; set; }
            public int groupId { get; set; }

        }
    }
}
